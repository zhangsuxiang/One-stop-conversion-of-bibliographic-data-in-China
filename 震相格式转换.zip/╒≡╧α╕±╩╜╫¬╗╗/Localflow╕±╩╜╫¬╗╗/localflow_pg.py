#!/usr/bin/env python3
"""
Reads parameter file 'idp_hypoDD.inp', reads event catalog,
converts JOPENS-format files to localflow phase format,
preserving core I/O logic:
- Only Pg recognized as P; only Sg recognized as S (skip Pn/Sn)
- Filter earliest P-phase and earliest S-phase per station
- Travel time threshold filtering (P<=20s, S<=40s)
Usage:
    python localflow_pg.py
    
Author: Suxiang Zhang
Work unit: Shanghai Earthquake Agency
"""
import os
import sys


def read_parameters(param_file='idp_hypoDD.inp'):
    lines = []
    try:
        with open(param_file, 'r', encoding='utf-8', errors='ignore') as f:
            for raw in f:
                line = raw.rstrip('\n')
                if line.strip().startswith('*') or not line.strip():
                    continue
                lines.append(line.strip())
    except FileNotFoundError:
        sys.exit(f"Parameter file '{param_file}' not found.")
    if len(lines) < 3:
        sys.exit(f"Need at least 3 non-comment lines in {param_file}.")
    return lines[0], lines[1], int(lines[2])


def parse_event_line(ln):
    lst = list(ln)
    for p in (7, 10, 16, 19):
        if p < len(lst): lst[p] = ' '
    s = ''.join(lst)
    parts = s[:58].split()
    year, mon, day = map(int, parts[1:4])
    h, mi = int(parts[4]), int(parts[5])
    sec = float(parts[6])
    lat, lon, dep, mag = map(float, parts[7:11])
    mag = max(mag, 0.0)
    t1 = h*3600 + mi*60 + sec
    return year, mon, day, h, mi, sec, lat, lon, dep, mag, t1


def parse_obs_line(ln, t1):
    lst = list(ln)
    for p in (34, 37):
        if p < len(lst): lst[p] = ' '
    s = ''.join(lst)
    fields = s[17:44].split()
    if len(fields) < 6:
        return None, None, None, None, None
    rawpha = fields[0]
    # only Pg and Sg
    if rawpha == 'Pg':
        pchar = 'P'
    elif rawpha == 'Sg':
        pchar = 'S'
    else:
        return None, None, None, None, None
    try:
        h2 = int(float(fields[3])); m2 = int(float(fields[4])); sec2 = float(fields[5])
    except ValueError:
        return None, None, None, None, None
    t2 = h2*3600 + m2*60 + sec2
    tt = t2 - t1
    if tt <= 0:
        return None, None, None, None, None
    if s[:3] != '   ':
        sc = s[0:2].strip()
        sx = s[2:7].strip()
    else:
        return None, None, None, None, None
    return sc, sx, tt, rawpha, pchar


def main():
    evcat, phaseps, istart = read_parameters()
    try:
        with open(evcat, 'r', encoding='utf-8', errors='ignore') as f:
            evfiles = [l.strip() for l in f if l.strip()]
    except FileNotFoundError:
        sys.exit(f"Event catalog '{evcat}' not found.")

    nev = 0
    prev_j2 = False
    with open(phaseps, 'w', encoding='utf-8', errors='ignore') as fout:
        for evf in evfiles:
            if not os.path.exists(evf):
                print(f"Warning: event file '{evf}' not found, skipping.")
                continue
            prev_t1 = 0.0
            printed_P = set()
            printed_S = set()
            skip_P = set()
            skip_S = set()
            prev_sc = ''
            prev_sx = ''
            with open(evf, 'r', encoding='utf-8', errors='ignore') as fev:
                for raw in fev:
                    ln = raw.rstrip('\n')
                    slash = len(ln) >= 8 and ln[7] == '/'
                    region_nb = any(ch != ' ' for ch in ln[25:42])
                    if slash:
                        prev_j2 = region_nb
                    if slash and prev_j2:
                        nev += 1
                        y, m, d, h, mi, s, lat, lon, dep, mag, t1 = parse_event_line(ln)
                        gid = nev + istart - 1
                        fout.write(
                            f"#{y:5d} {m:2d} {d:2d} {h:2d} {mi:2d} {s:5.2f} "
                            f"{lat:8.4f} {lon:9.4f} {dep:7.2f}  {mag:5.2f}  {gid:10d}\n"
                        )
                        prev_t1 = t1
                        printed_P.clear()
                        printed_S.clear()
                        skip_P.clear()
                        skip_S.clear()
                        prev_sc = ''
                        prev_sx = ''
                    elif not slash and prev_j2 and region_nb:
                        # mark stations with Pn/Sn for skipping
                        rawpha_peek = ''.join(list(ln)[:44])[17:44].split()[0] if len(ln) >= 44 else ''
                        if rawpha_peek == 'Pn':
                            skip_P.add(prev_sc + prev_sx)
                        elif rawpha_peek == 'Sn':
                            skip_S.add(prev_sc + prev_sx)
                        sc, sx, tt, rawpha, pchar = parse_obs_line(ln, prev_t1)
                        if sc is None:
                            continue
                        prev_sc, prev_sx = sc, sx
                        key = sc + sx
                        # skip any P/S if Pn/Sn occurred at that station
                        if pchar == 'P' and key in skip_P:
                            continue
                        if pchar == 'S' and key in skip_S:
                            continue
                        # threshold filtering
                        if (pchar == 'P' and tt > 20.0) or (pchar == 'S' and tt > 40.0):
                            continue
                        # earliest-phase filtering
                        if pchar == 'P':
                            if key in printed_P:
                                continue
                            printed_P.add(key)
                        else:
                            if key in printed_S:
                                continue
                            printed_S.add(key)
                        fout.write(f"{sc}{sx} {sc} {tt:8.2f} {pchar}\n")
        fout.flush()
    print(f"Finished: events={nev}, output={phaseps}")

if __name__ == '__main__':
    main()
