#!/usr/bin/env python3
"""
Reads parameter file 'idp_hypoDD.inp', reads event catalog,
converts JOPENS-format files to tomoDD phase format,
preserving Fortran I/O order and constraints.
Usage:
    python tomodd.py
    
Author: Suxiang Zhang
Work unit: Shanghai Earthquake Agency
"""
import os

def read_parameters(param_file='idp_hypoDD.inp'):
    lines = []
    with open(param_file, 'r', encoding='utf-8', errors='ignore') as f:
        for raw in f:
            line = raw.rstrip('\n')
            if line.strip().startswith('*') or not line.strip():
                continue
            lines.append(line.strip())
    if len(lines) < 3:
        raise ValueError('Need at least 3 non-comment lines in ' + param_file)
    return lines[0], lines[1], int(lines[2])


def parse_event_line(ln):
    lst = list(ln)
    for p in (7, 10, 16, 19):
        if p < len(lst):
            lst[p] = ' '
    s = ''.join(lst)
    parts = s[:58].split()
    year, mon, day = map(int, parts[1:4])
    h, mi = int(parts[4]), int(parts[5])
    sec = float(parts[6])
    lat, lon, dep, mag = map(float, parts[7:11])
    if mag < 0:
        mag = 0.0
    t1 = h * 3600 + mi * 60 + sec
    return year, mon, day, h, mi, sec, lat, lon, dep, mag, t1


def parse_obs_line(ln, t1):
    lst = list(ln)
    for p in (34, 37):
        if p < len(lst):
            lst[p] = ' '
    s = ''.join(lst)
    sub = s[17:44].split()
    if len(sub) < 6:
        return None, None, None, None, None
    pha = sub[0]
    try:
        h2 = int(float(sub[3])); m2 = int(float(sub[4])); sec2 = float(sub[5])
    except:
        return None, None, None, None, None
    t2 = h2 * 3600 + m2 * 60 + sec2
    tt = t2 - t1
    # Exact Fortran phase matching
    if pha in ('Pg', 'Pn'):
        w, pchar = 1.00, 'P'
    elif pha == 'P':
        w, pchar = 0.50, 'P'
    elif pha in ('Sg', 'Sn'):
        w, pchar = 0.75, 'S'
    elif pha == 'S':
        w, pchar = 0.25, 'S'
    else:
        return None, None, None, None, None
    # station index
    if s[:3] != '   ':
        sc = s[0:2]
        sx = s[2:7]
    else:
        sc = None
        sx = None
    return sc, sx, tt, w, pchar


def main():
    evcat, phaseps, istart = read_parameters()
    with open(evcat, 'r', encoding='utf-8', errors='ignore') as f:
        evfiles = [l.strip() for l in f if l.strip()]
    fout = open(phaseps, 'w', encoding='utf-8', errors='ignore')
    nev = 0
    prev_j2 = False

    for evf in evfiles:
        if not os.path.exists(evf):
            continue
        prev_t1 = 0.0
        printed_S = set()
        prev_sc = ''
        prev_sx = ''
        with open(evf, 'r', encoding='utf-8', errors='ignore') as fev:
            for raw in fev:
                ln = raw.rstrip('\n')
                slash = len(ln) >= 8 and ln[7] == '/'
                region_nb = any(ch != ' ' for ch in ln[25:42])
                if slash:
                    prev_j2 = region_nb
                if slash and prev_j2:
                    # event header
                    nev += 1
                    y, m, d, h, mi, s, lat, lon, dep, mag, t1 = parse_event_line(ln)
                    gid = nev + istart - 1
                    fout.write(f"#{y:5d} {m:2d} {d:2d} {h:2d} {mi:2d} {s:5.2f} "
                               + f"{lat:8.4f} {lon:9.4f} {dep:7.2f}  {mag:5.2f}{0:6.2f}{0:6.2f}{0:6.2f} {gid:10d}\n")
                    prev_t1 = t1
                    printed_S.clear()
                    prev_sc = ''
                    prev_sx = ''
                elif not slash and prev_j2 and region_nb:
                    sc, sx, tt, w, pchar = parse_obs_line(ln, prev_t1)
                    if sc is not None:
                        prev_sc = sc
                        prev_sx = sx
                    sc = prev_sc.strip()
                    sx = prev_sx.strip()
                    if tt is None or tt <= 0:
                        continue
                    if pchar == 'S':
                        key = sc + sx
                        if key in printed_S:
                            continue
                        printed_S.add(key)
                    fout.write(f"{sc}{sx:<5}  {tt:8.2f}  {w:5.2f}  {pchar}\n")
    fout.close()
    print(f"Finished: events={nev}, output={phaseps}")

if __name__ == '__main__':
    main()
