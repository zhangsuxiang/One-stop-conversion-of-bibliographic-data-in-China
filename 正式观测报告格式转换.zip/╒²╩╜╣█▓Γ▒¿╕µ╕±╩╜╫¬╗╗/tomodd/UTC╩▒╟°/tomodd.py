#!/usr/bin/env python3
"""
Reads parameter file 'idp_hypoDD.inp', reads event catalog,
converts both JOPENS-format and new DBO/DPB format files to tomoDD phase format,
preserving Fortran I/O order and constraints.
Converts China Time (UTC+8) to UTC.
Usage:
    python tomodd.py
    
Author: Suxiang Zhang
Work unit: Shanghai Earthquake Agency
Modified to support new DBO/DPB format and UTC time conversion
"""
import os
import sys
from datetime import datetime, timedelta

# Maximum allowed travel time in seconds (used to filter out bad picks)
MAX_TRAVEL_TIME = 20000.0


def read_parameters(param_file='idp_hypoDD.inp'):
    lines = []
    with open(param_file, 'r', encoding='utf-8', errors='ignore') as f:
        for raw in f:
            line = raw.rstrip('\n')
            if line.strip().startswith('*') or not line.strip():
                continue
            lines.append(line.strip())
    if len(lines) < 3:
        raise ValueError('Need at least 3 non-comment lines in ' + param_file)
    return lines[0], lines[1], int(lines[2])


def china_time_to_utc(year, mon, day, h, mi, sec):
    """Convert China Time (UTC+8) to UTC"""
    try:
        # Create datetime object for China Time
        china_dt = datetime(year, mon, day, h, mi, int(sec))
        # Add microseconds
        microsec = int((sec - int(sec)) * 1e6)
        china_dt = china_dt.replace(microsecond=microsec)
        
        # Convert to UTC (subtract 8 hours)
        utc_dt = china_dt - timedelta(hours=8)
        
        # Extract components
        utc_sec = utc_dt.second + utc_dt.microsecond / 1e6
        return utc_dt.year, utc_dt.month, utc_dt.day, utc_dt.hour, utc_dt.minute, utc_sec
    except:
        # If conversion fails, return original values
        return year, mon, day, h, mi, sec


def parse_event_line(ln):
    """Parse JOPENS format event line and convert to UTC"""
    lst = list(ln)
    for p in (7, 10, 16, 19):
        if p < len(lst):
            lst[p] = ' '
    s = ''.join(lst)
    parts = s[:58].split()
    year, mon, day = map(int, parts[1:4])
    h, mi = int(parts[4]), int(parts[5])
    sec = float(parts[6])
    lat, lon, dep, mag = map(float, parts[7:11])
    if mag < 0:
        mag = 0.0
    
    # Store China time for travel time calculation
    t1_china = h * 3600 + mi * 60 + sec
    china_dt = datetime(year, mon, day, h, mi, int(sec))
    
    # Convert to UTC for output
    year_utc, mon_utc, day_utc, h_utc, mi_utc, sec_utc = china_time_to_utc(year, mon, day, h, mi, sec)
    
    return year_utc, mon_utc, day_utc, h_utc, mi_utc, sec_utc, lat, lon, dep, mag, china_dt


def parse_dbo_event_line(ln):
    """Parse DBO format event line and convert to UTC"""
    parts = ln.split()
    if len(parts) < 10:
        return None
    
    # Parse date and time (China Time)
    date_time = parts[2] + ' ' + parts[3]  # "2024-12-31 17:17:07.64"
    date_part, time_part = date_time.split()
    year, mon, day = map(int, date_part.split('-'))
    time_parts = time_part.split(':')
    h = int(time_parts[0])
    mi = int(time_parts[1])
    sec = float(time_parts[2])
    
    # Parse location - lat and lon are after time
    lat = float(parts[4])
    lon = float(parts[5])
    
    # Find depth and magnitude
    dep = 0.0
    mag = 0.0
    
    for i in range(6, len(parts)):
        try:
            val = float(parts[i])
            if dep == 0.0 and 0 <= val <= 700:  # depths are typically 0-700 km
                dep = val
        except ValueError:
            if parts[i] in ['ML', 'Ms', 'mb', 'mB', 'Mw']:
                if i+1 < len(parts):
                    try:
                        mag = float(parts[i+1])
                    except ValueError:
                        pass
    
    if mag < 0:
        mag = 0.0
    
    # Store China time datetime for travel time calculation
    china_dt = datetime(year, mon, day, h, mi, int(sec))
    microsec = int((sec - int(sec)) * 1e6)
    china_dt = china_dt.replace(microsecond=microsec)
    
    # Convert to UTC for output
    year_utc, mon_utc, day_utc, h_utc, mi_utc, sec_utc = china_time_to_utc(year, mon, day, h, mi, sec)
    
    return year_utc, mon_utc, day_utc, h_utc, mi_utc, sec_utc, lat, lon, dep, mag, china_dt


def parse_obs_line(ln, origin_dt):
    """Parse JOPENS format observation line"""
    lst = list(ln)
    for p in (34, 37):
        if p < len(lst):
            lst[p] = ' '
    s = ''.join(lst)
    sub = s[17:44].split()
    if len(sub) < 6:
        return None, None, None, None, None
    pha = sub[0]
    try:
        h2 = int(float(sub[3])); m2 = int(float(sub[4])); sec2 = float(sub[5])
    except:
        return None, None, None, None, None
    
    # Create arrival datetime (China Time)
    arrival_dt = origin_dt.replace(hour=h2, minute=m2, second=int(sec2), microsecond=0)
    microsec = int((sec2 - int(sec2)) * 1e6)
    arrival_dt = arrival_dt.replace(microsecond=microsec)
    
    # Handle day crossing
    if arrival_dt < origin_dt:
        arrival_dt = arrival_dt + timedelta(days=1)
    
    # Calculate travel time in seconds
    tt = (arrival_dt - origin_dt).total_seconds()

    # Guard against negative travel times (e.g., picks that cross midnight)
    if tt < 0 and abs(tt) <= 86400:
        tt += 86400

    # Filter invalid or unreasonably large travel times
    if tt <= 0 or tt > MAX_TRAVEL_TIME:
        return None, None, None, None, None
    
    # Exact Fortran phase matching
    if pha in ('Pg', 'Pn'):
        w, pchar = 1.00, 'P'
    elif pha == 'P':
        w, pchar = 0.50, 'P'
    elif pha in ('Sg', 'Sn'):
        w, pchar = 0.85, 'S'
    elif pha == 'S':
        w, pchar = 0.50, 'S'
    else:
        return None, None, None, None, None
    
    # station index
    if s[:3] != '   ':
        sc = s[0:2]
        sx = s[2:7]
    else:
        sc = None
        sx = None
    return sc, sx, tt, w, pchar


def parse_dpb_obs_line(ln, origin_dt):
    """Parse DPB format observation line"""
    parts = ln.split()
    if len(parts) < 6:
        return None, None, None, None, None
    
    # Extract station info
    network = parts[1]  # e.g., 'SC', 'YN'
    station = parts[2]  # e.g., 'JLO', 'JNZE'
    
    # Look for phase name
    phase = None
    for i in range(3, min(10, len(parts))):
        if parts[i] in ('Pg', 'Pn', 'Sg', 'Sn', 'P', 'S'):
            phase = parts[i]
            break
    
    if not phase:
        return None, None, None, None, None
    
    # Find the date-time pattern - parse complete arrival time (China Time)
    arrival_dt = None
    
    for i in range(len(parts)):
        if '-' in parts[i] and len(parts[i]) == 10:
            try:
                year_test = int(parts[i][:4])
                if 1900 <= year_test <= 2100:
                    if i+1 < len(parts) and ':' in parts[i+1]:
                        # Parse arrival date and time
                        date_str = parts[i]
                        time_str = parts[i+1]
                        
                        year_arr, mon_arr, day_arr = map(int, date_str.split('-'))
                        time_parts = time_str.split(':')
                        if len(time_parts) == 3:
                            h2 = int(time_parts[0])
                            m2 = int(time_parts[1])
                            sec2 = float(time_parts[2])
                            
                            # Create arrival datetime (China Time)
                            arrival_dt = datetime(year_arr, mon_arr, day_arr, h2, m2, int(sec2))
                            microsec = int((sec2 - int(sec2)) * 1e6)
                            arrival_dt = arrival_dt.replace(microsecond=microsec)
                            break
            except (ValueError, IndexError):
                continue
    
    if arrival_dt is None:
        # Fallback: some DPB files may not include the full YYYY-MM-DD field.
        # Try to find a time token like HH:MM:SS(.sss) and assume the origin date.
        for tok in parts:
            if ':' in tok and tok.count(':') == 2:
                try:
                    h2_s, m2_s, s2_s = tok.split(':')
                    h2 = int(h2_s)
                    m2 = int(m2_s)
                    sec2 = float(s2_s)
                    microsec = int((sec2 - int(sec2)) * 1e6)
                    arrival_dt = origin_dt.replace(hour=h2, minute=m2, second=int(sec2), microsecond=microsec)
                    # If the inferred arrival is earlier than the origin, treat it as next-day pick
                    if arrival_dt < origin_dt:
                        arrival_dt = arrival_dt + timedelta(days=1)
                    break
                except Exception:
                    continue

    if arrival_dt is None:
        return None, None, None, None, None

    # Calculate travel time
    tt = (arrival_dt - origin_dt).total_seconds()

    # Guard against negative travel times due to midnight crossing / missing date fields
    if tt < 0 and abs(tt) <= 86400:
        tt += 86400

    # Filter invalid or unreasonably large travel times
    if tt <= 0 or tt > MAX_TRAVEL_TIME:
        return None, None, None, None, None
    
    # Phase weights (same as original)
    if phase in ('Pg', 'Pn'):
        w, pchar = 1.00, 'P'
    elif phase == 'P':
        w, pchar = 0.50, 'P'
    elif phase in ('Sg', 'Sn'):
        w, pchar = 0.75, 'S'
    elif phase == 'S':
        w, pchar = 0.25, 'S'
    else:
        return None, None, None, None, None
    
    # Format station code - pad to correct width
    sc = network[:2].ljust(2)
    sx = station[:5].ljust(5)
    
    return sc, sx, tt, w, pchar


def detect_format(filename):
    """Detect file format by checking first few lines"""
    with open(filename, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            line = line.strip()
            if line.startswith('DBO'):
                return 'DBO'
            elif len(line) > 10 and line[7] == '/' and line[10] == '/':
                return 'JOPENS'
    return None


def process_dbo_format(filename, fout, nev_start, istart):
    """Process DBO/DPB format file"""
    nev = nev_start
    current_origin_dt = None
    current_event_processed = False
    printed_S = set()
    
    with open(filename, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            line = line.strip()
            
            if line.startswith('DBO'):
                # Parse new event
                event_data = parse_dbo_event_line(line)
                if event_data:
                    nev += 1
                    y, m, d, h, mi, s, lat, lon, dep, mag, origin_dt = event_data
                    gid = nev + istart - 1
                    fout.write(f"#{y:5d} {m:2d} {d:2d} {h:2d} {mi:2d} {s:5.2f} "
                               + f"{lat:8.4f} {lon:9.4f} {dep:7.2f}  {mag:5.2f}{0:6.2f}{0:6.2f}{0:6.2f} {gid:10d}\n")
                    current_origin_dt = origin_dt
                    current_event_processed = True
                    printed_S.clear()
            
            elif line.startswith('DPB') and current_origin_dt is not None:
                # Parse observation line
                sc, sx, tt, w, pchar = parse_dpb_obs_line(line, current_origin_dt)
                
                if sc is not None and sx is not None and tt is not None and tt > 0:
                    # Handle S-wave duplicates
                    if pchar == 'S':
                        key = sc.strip() + sx.strip()
                        if key in printed_S:
                            continue
                        printed_S.add(key)
                    
                    # Output: network station traveltime weight phase
                    fout.write(f"{sc} {sx:<5}  {tt:8.2f}  {w:5.2f}  {pchar}\n")
    
    return nev


def process_jopens_format(filename, fout, nev_start, istart):
    """Process JOPENS format file"""
    nev = nev_start
    prev_j2 = False
    current_origin_dt = None
    printed_S = set()
    prev_sc = ''
    prev_sx = ''
    
    with open(filename, 'r', encoding='utf-8', errors='ignore') as fev:
        for raw in fev:
            ln = raw.rstrip('\n')
            slash = len(ln) >= 8 and ln[7] == '/'
            region_nb = any(ch != ' ' for ch in ln[25:42])
            if slash:
                prev_j2 = region_nb
            if slash and prev_j2:
                # event header
                nev += 1
                y, m, d, h, mi, s, lat, lon, dep, mag, origin_dt = parse_event_line(ln)
                gid = nev + istart - 1
                fout.write(f"#{y:5d} {m:2d} {d:2d} {h:2d} {mi:2d} {s:5.2f} "
                           + f"{lat:8.4f} {lon:9.4f} {dep:7.2f}  {mag:5.2f}{0:6.2f}{0:6.2f}{0:6.2f} {gid:10d}\n")
                current_origin_dt = origin_dt
                printed_S.clear()
                prev_sc = ''
                prev_sx = ''
            elif not slash and prev_j2 and region_nb:
                sc, sx, tt, w, pchar = parse_obs_line(ln, current_origin_dt)
                if sc is not None:
                    prev_sc = sc
                    prev_sx = sx
                sc = prev_sc.strip()
                sx = prev_sx.strip()
                if tt is None or tt <= 0:
                    continue
                if pchar == 'S':
                    key = sc + sx
                    if key in printed_S:
                        continue
                    printed_S.add(key)
                # Output: network station traveltime weight phase
                fout.write(f"{sc} {sx:<5}  {tt:8.2f}  {w:5.2f}  {pchar}\n")
    
    return nev


def main():
    evcat, phaseps, istart = read_parameters()
    
    # Check if evcat is a list file or a single file
    if os.path.exists(evcat):
        # Try to detect if it's a catalog list or a data file
        with open(evcat, 'r', encoding='utf-8', errors='ignore') as f:
            first_line = f.readline().strip()
            f.seek(0)  # Reset to beginning
            
            # If first line starts with DBO, it's a data file, not a catalog list
            if first_line.startswith('DBO'):
                evfiles = [evcat]  # Treat as single data file
            else:
                # It's a catalog list
                evfiles = [l.strip() for l in f if l.strip()]
    else:
        print(f"Error: Cannot find file {evcat}")
        return
    
    fout = open(phaseps, 'w', encoding='utf-8', errors='ignore')
    nev = 0
    
    for evf in evfiles:
        if not os.path.exists(evf):
            continue
        
        # Detect format
        file_format = detect_format(evf)
        if not file_format:
            continue
        
        print(f"Processing {evf} in {file_format} format...")
        
        if file_format == 'JOPENS':
            nev = process_jopens_format(evf, fout, nev, istart)
        elif file_format == 'DBO':
            nev = process_dbo_format(evf, fout, nev, istart)
    
    fout.close()
    print(f"Finished: events={nev}, output={phaseps}")

if __name__ == '__main__':
    main()