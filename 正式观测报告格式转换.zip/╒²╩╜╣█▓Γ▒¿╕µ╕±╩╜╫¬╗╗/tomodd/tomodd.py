#!/usr/bin/env python3
"""
Reads parameter file 'idp_hypoDD.inp', reads event catalog,
converts both JOPENS-format and new DBO/DPB format files to tomoDD phase format,
preserving Fortran I/O order and constraints.
Usage:
    python tomodd.py
    
Author: Suxiang Zhang
Work unit: Shanghai Earthquake Agency
Modified to support new DBO/DPB format
"""
import os
from datetime import datetime, timedelta

def read_parameters(param_file='idp_hypoDD.inp'):
    lines = []
    with open(param_file, 'r', encoding='utf-8', errors='ignore') as f:
        for raw in f:
            line = raw.rstrip('\n')
            if line.strip().startswith('*') or not line.strip():
                continue
            lines.append(line.strip())
    if len(lines) < 3:
        raise ValueError('Need at least 3 non-comment lines in ' + param_file)
    return lines[0], lines[1], int(lines[2])


def parse_event_line(ln):
    """Parse JOPENS format event line"""
    lst = list(ln)
    for p in (7, 10, 16, 19):
        if p < len(lst):
            lst[p] = ' '
    s = ''.join(lst)
    parts = s[:58].split()
    year, mon, day = map(int, parts[1:4])
    h, mi = int(parts[4]), int(parts[5])
    sec = float(parts[6])
    lat, lon, dep, mag = map(float, parts[7:11])
    if mag < 0:
        mag = 0.0
    t1 = h * 3600 + mi * 60 + sec
    return year, mon, day, h, mi, sec, lat, lon, dep, mag, t1


def parse_dbo_event_line(ln):
    """Parse DBO format event line"""
    parts = ln.split()
    if len(parts) < 10:
        return None
    
    # Parse date and time
    date_time = parts[2] + ' ' + parts[3]  # "2024-12-31 17:17:07.64"
    date_part, time_part = date_time.split()
    year, mon, day = map(int, date_part.split('-'))
    time_parts = time_part.split(':')
    h = int(time_parts[0])
    mi = int(time_parts[1])
    sec = float(time_parts[2])
    
    # Parse location - lat and lon are after time
    lat = float(parts[4])
    lon = float(parts[5])
    
    # Find depth and magnitude
    # Look for magnitude type (ML, MS, mb, etc.) and get the value after it
    dep = 0.0
    mag = 0.0
    
    for i in range(6, len(parts)):
        try:
            # Try to convert to float
            val = float(parts[i])
            # If we haven't found depth yet and the value is reasonable for depth
            if dep == 0.0 and 0 <= val <= 700:  # depths are typically 0-700 km
                dep = val
        except ValueError:
            # Check if this is a magnitude type
            if parts[i] in ['ML', 'Ms', 'mb', 'mB', 'Mw']:
                # The next element should be the magnitude value
                if i+1 < len(parts):
                    try:
                        mag = float(parts[i+1])
                    except ValueError:
                        pass
    
    t1 = h * 3600 + mi * 60 + sec
    return year, mon, day, h, mi, sec, lat, lon, dep, mag, t1


def parse_obs_line(ln, t1):
    """Parse JOPENS format observation line"""
    lst = list(ln)
    for p in (34, 37):
        if p < len(lst):
            lst[p] = ' '
    s = ''.join(lst)
    sub = s[17:44].split()
    if len(sub) < 6:
        return None, None, None, None, None
    pha = sub[0]
    try:
        h2 = int(float(sub[3])); m2 = int(float(sub[4])); sec2 = float(sub[5])
    except:
        return None, None, None, None, None
    t2 = h2 * 3600 + m2 * 60 + sec2
    tt = t2 - t1
    # Handle cross-day picks: if arrival time is after midnight of the next day
    # JOPENS pick lines usually have no date, only HH:MM:SS.
    if tt < 0:
        tt += 86400.0
    # Guard against obviously invalid travel times (e.g., wrong-day or malformed picks)
    if tt <= 0 or tt > 20000:
        return None, None, None, None, None
    # Exact Fortran phase matching
    if pha in ('Pg', 'Pn'):
        w, pchar = 1.00, 'P'
    elif pha == 'P':
        w, pchar = 0.50, 'P'
    elif pha in ('Sg', 'Sn'):
        w, pchar = 0.85, 'S'
    elif pha == 'S':
        w, pchar = 0.50, 'S'
    else:
        return None, None, None, None, None
    # station index
    if s[:3] != '   ':
        sc = s[0:2]
        sx = s[2:7]
    else:
        sc = None
        sx = None
    return sc, sx, tt, w, pchar


def parse_dpb_obs_line(ln, event_dt=None, t1=None):
    """Parse DPB format observation line.

    Notes on time handling:
    - If the DPB line contains an explicit date (YYYY-MM-DD) and time, we compute tt using full datetimes.
      This correctly handles cross-day (and cross-month/year) arrivals.
    - If no date is found, we fall back to seconds-of-day using t1, with a cross-day correction (tt += 86400 if tt < 0).
    """
    # Example line:
    # DPB SC   JLO BHZ   U      Pg 1  V 2024-12-31 17:17:24.67    0.29   95.7  62.6

    parts = ln.split()
    if len(parts) < 6:
        return None, None, None, None, None

    # Extract station info
    network = parts[1]  # e.g., 'SC', 'YN'
    station = parts[2]  # e.g., 'JLO', 'JNZE'

    # Look for common phase names within the first ~10 tokens
    phase = None
    for i in range(3, min(10, len(parts))):
        if parts[i] in ('Pg', 'Pn', 'Sg', 'Sn', 'P', 'S'):
            phase = parts[i]
            break
    if not phase:
        return None, None, None, None, None

    # Try to find a date token YYYY-MM-DD and the following time token HH:MM:SS(.sss)
    arrival_dt = None
    for i in range(len(parts) - 1):
        tok = parts[i]
        if '-' in tok and len(tok) == 10:
            try:
                yy = int(tok[0:4])
                mm = int(tok[5:7])
                dd = int(tok[8:10])
                # Next token should be time
                tstr = parts[i + 1]
                if ':' not in tstr:
                    continue
                tparts = tstr.split(':')
                if len(tparts) != 3:
                    continue
                hh = int(tparts[0])
                mi = int(tparts[1])
                secf = float(tparts[2])
                sec_i = int(secf)
                usec = int(round((secf - sec_i) * 1e6))
                # Normalize microseconds if rounding pushed to 1e6
                if usec >= 1000000:
                    sec_i += 1
                    usec -= 1000000
                arrival_dt = datetime(yy, mm, dd, hh, mi, sec_i, usec)
                break
            except Exception:
                continue

    # Compute travel time (seconds)
    tt = None
    if arrival_dt is not None and event_dt is not None:
        tt = (arrival_dt - event_dt).total_seconds()
    elif arrival_dt is not None and event_dt is None and t1 is not None:
        # We have a date on the pick, but not the event datetime. Fall back to seconds-of-day.
        # This may still be wrong across midnight if event and pick are different dates,
        # but we attempt a cross-day correction.
        arrival_time = arrival_dt.hour * 3600 + arrival_dt.minute * 60 + (arrival_dt.second + arrival_dt.microsecond / 1e6)
        tt = arrival_time - float(t1)
        if tt < 0:
            tt += 86400.0
    else:
        # No date found on the pick: seconds-of-day fallback
        if t1 is None:
            return None, None, None, None, None
        # Find a time-like token HH:MM:SS(.sss)
        arrival_time = None
        for tok in parts:
            if tok.count(':') == 2:
                try:
                    h2, m2, s2 = tok.split(':')
                    h2 = int(h2); m2 = int(m2); sec2 = float(s2)
                    arrival_time = h2 * 3600 + m2 * 60 + sec2
                    break
                except Exception:
                    continue
        if arrival_time is None:
            return None, None, None, None, None
        tt = float(arrival_time) - float(t1)
        if tt < 0:
            tt += 86400.0

    # Basic sanity checks
    if tt is None or tt <= 0 or tt > 20000:
        return None, None, None, None, None

    # Phase weights (same as original)
    if phase in ('Pg', 'Pn'):
        w, pchar = 1.00, 'P'
    elif phase == 'P':
        w, pchar = 0.50, 'P'
    elif phase in ('Sg', 'Sn'):
        w, pchar = 0.85, 'S'
    elif phase == 'S':
        w, pchar = 0.50, 'S'
    else:
        return None, None, None, None, None

    # Format station code - pad to correct width
    sc = network[:2].ljust(2)
    sx = station[:5].ljust(5)

    return sc, sx, float(tt), w, pchar
def detect_format(filename):
    """Detect file format by checking first few lines"""
    with open(filename, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            line = line.strip()
            if line.startswith('DBO'):
                return 'DBO'
            elif len(line) > 10 and line[7] == '/' and line[10] == '/':
                return 'JOPENS'
    return None


def process_dbo_format(filename, fout, nev_start, istart):
    """Process DBO/DPB format file"""
    nev = nev_start
    current_t1 = 0.0
    current_event_dt = None
    current_event_processed = False
    printed_S = set()
    
    with open(filename, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            line = line.strip()
            
            if line.startswith('DBO'):
                # If we have a previous event with phases, ensure we've written them
                if current_event_processed:
                    printed_S.clear()
                
                # Parse new event
                event_data = parse_dbo_event_line(line)
                if event_data:
                    nev += 1
                    y, m, d, h, mi, s, lat, lon, dep, mag, t1 = event_data
                    gid = nev + istart - 1
                    fout.write(f"#{y:5d} {m:2d} {d:2d} {h:2d} {mi:2d} {s:5.2f} "
                               + f"{lat:8.4f} {lon:9.4f} {dep:7.2f}  {mag:5.2f}{0:6.2f}{0:6.2f}{0:6.2f} {gid:10d}\n")
                    current_t1 = t1
                    # Store full event datetime for robust travel-time computation across midnight
                    sec_i = int(s)
                    usec = int(round((s - sec_i) * 1e6))
                    if usec >= 1000000:
                        sec_i += 1
                        usec -= 1000000
                    current_event_dt = datetime(y, m, d, h, mi, sec_i, usec)
                    current_event_processed = True
                    printed_S.clear()
            
            elif line.startswith('DPB') and current_t1 > 0:
                # Parse observation line
                sc, sx, tt, w, pchar = parse_dpb_obs_line(line, event_dt=current_event_dt, t1=current_t1)
                
                if sc is not None and sx is not None and tt is not None and tt > 0:
                    # Handle S-wave duplicates
                    if pchar == 'S':
                        key = sc.strip() + sx.strip()
                        if key in printed_S:
                            continue
                        printed_S.add(key)
                    
                    # 在台网名(sc)和台站名(sx)之间添加空格
#                    fout.write(f"{sc} {sx:<5}  {tt:8.2f}  {w:5.2f}  {pchar}\n")
                    # 台网+台站，去掉中间空格，例如 SCJLO
                    sta = (sc.strip() + sx.strip())
                    fout.write(f"{sta:<7}  {tt:8.2f}  {w:5.2f}  {pchar}\n")
    
    return nev


def process_jopens_format(filename, fout, nev_start, istart):
    """Process JOPENS format file"""
    nev = nev_start
    prev_j2 = False
    prev_t1 = 0.0
    printed_S = set()
    prev_sc = ''
    prev_sx = ''
    
    with open(filename, 'r', encoding='utf-8', errors='ignore') as fev:
        for raw in fev:
            ln = raw.rstrip('\n')
            slash = len(ln) >= 8 and ln[7] == '/'
            region_nb = any(ch != ' ' for ch in ln[25:42])
            if slash:
                prev_j2 = region_nb
            if slash and prev_j2:
                # event header
                nev += 1
                y, m, d, h, mi, s, lat, lon, dep, mag, t1 = parse_event_line(ln)
                gid = nev + istart - 1
                fout.write(f"#{y:5d} {m:2d} {d:2d} {h:2d} {mi:2d} {s:5.2f} "
                           + f"{lat:8.4f} {lon:9.4f} {dep:7.2f}  {mag:5.2f}{0:6.2f}{0:6.2f}{0:6.2f} {gid:10d}\n")
                prev_t1 = t1
                printed_S.clear()
                prev_sc = ''
                prev_sx = ''
            elif not slash and prev_j2 and region_nb:
                sc, sx, tt, w, pchar = parse_obs_line(ln, prev_t1)
                if sc is not None:
                    prev_sc = sc
                    prev_sx = sx
                sc = prev_sc.strip()
                sx = prev_sx.strip()
                if tt is None or tt <= 0:
                    continue
                if pchar == 'S':
                    key = sc + sx
                    if key in printed_S:
                        continue
                    printed_S.add(key)
                # 在台网名(sc)和台站名(sx)之间添加空格
#                fout.write(f"{sc} {sx:<5}  {tt:8.2f}  {w:5.2f}  {pchar}\n")
                # 台网+台站，去掉中间空格
                sta = (sc + sx).strip()
                fout.write(f"{sta:<7}  {tt:8.2f}  {w:5.2f}  {pchar}\n")
    
    return nev


def main():
    evcat, phaseps, istart = read_parameters()
    
    # Check if evcat is a list file or a single file
    if os.path.exists(evcat):
        # Try to detect if it's a catalog list or a data file
        with open(evcat, 'r', encoding='utf-8', errors='ignore') as f:
            first_line = f.readline().strip()
            f.seek(0)  # Reset to beginning
            
            # If first line starts with DBO, it's a data file, not a catalog list
            if first_line.startswith('DBO'):
                evfiles = [evcat]  # Treat as single data file
            else:
                # It's a catalog list
                evfiles = [l.strip() for l in f if l.strip()]
    else:
        print(f"Error: Cannot find file {evcat}")
        return
    
    fout = open(phaseps, 'w', encoding='utf-8', errors='ignore')
    nev = 0
    
    for evf in evfiles:
        if not os.path.exists(evf):
            continue
        
        # Detect format
        file_format = detect_format(evf)
        if not file_format:
            continue
        
        print(f"Processing {evf} in {file_format} format...")
        
        if file_format == 'JOPENS':
            nev = process_jopens_format(evf, fout, nev, istart)
        elif file_format == 'DBO':
            nev = process_dbo_format(evf, fout, nev, istart)
    
    fout.close()
    print(f"Finished: events={nev}, output={phaseps}")
if __name__ == '__main__':
    main()