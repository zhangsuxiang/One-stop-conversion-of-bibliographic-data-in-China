#!/usr/bin/env python3
"""
Reads parameter file 'idp_hypoDD.inp', reads event catalog,
converts both JOPENS-format and DBO/DPB format files to localflow phase format,
preserving core I/O logic:
- Only Pg recognized as P; only Sg recognized as S (skip Pn/Sn)
- Filter earliest P-phase and earliest S-phase per station
- Travel time threshold filtering (P<=20s, S<=40s)
- Converts China Time (UTC+8) to UTC
Usage:
    python localflow_pg.py
    
Author: Suxiang Zhang
Work unit: Shanghai Earthquake Agency
Modified to support DBO/DPB format and UTC time conversion
"""
import os
import sys
from datetime import datetime, timedelta

# -----------------------------------------------------------------------------
# Cross-midnight travel-time fix (shared across JOPENS + DPB parsing)
# -----------------------------------------------------------------------------
MAX_TRAVEL_TIME_FALLBACK = 20000.0  # seconds; additional per-phase filters may apply later

def _parse_hms_token(tok):
    """Parse 'HH:MM:SS[.sss]' -> (h, m, sec_float) or None."""
    if tok is None or tok.count(':') != 2:
        return None
    parts = tok.split(':')
    if len(parts) != 3:
        return None
    try:
        h = int(parts[0]); m = int(parts[1]); sec = float(parts[2])
        if not (0 <= h <= 23 and 0 <= m <= 59 and 0.0 <= sec < 61.0):
            return None
        return h, m, sec
    except Exception:
        return None

def _build_datetime_ymd_hms(date_str, time_str):
    """Build datetime from 'YYYY-MM-DD' + 'HH:MM:SS[.sss]'. Returns None on failure."""
    try:
        y, mo, d = map(int, date_str.split('-'))
        hms = _parse_hms_token(time_str)
        if hms is None:
            return None
        h, m, sec = hms
        dt = datetime(y, mo, d, h, m, int(sec))
        micro = int((sec - int(sec)) * 1e6)
        return dt.replace(microsecond=micro)
    except Exception:
        return None

def compute_relative_tt(origin_dt, arrival_dt, max_tt=MAX_TRAVEL_TIME_FALLBACK):
    """Compute a robust, non-negative travel time in seconds.

    Strategy:
    - If (arrival - origin) is negative but within 1 day, assume it crossed midnight -> +86400.
    - Optionally reject ultra-large travel times (max_tt) to avoid promoting bad picks.
    """
    if origin_dt is None or arrival_dt is None:
        return None
    tt = (arrival_dt - origin_dt).total_seconds()
    if tt < 0 and abs(tt) <= 86400:
        tt += 86400
    if tt <= 0:
        return None
    if max_tt is not None and tt > max_tt:
        return None
    return tt

def compute_tt_from_tokens(origin_dt, date_str=None, time_str=None, max_tt=MAX_TRAVEL_TIME_FALLBACK):
    """Compute travel time from optional date+time tokens.

    - If date_str is present, prefer full datetime (YYYY-MM-DD + time).
    - If date_str is missing (common for some DPB variants), fall back to time-only using origin date,
      and if arrival appears earlier than origin, treat it as next-day.
    """
    arrival_dt = None
    if date_str and time_str:
        arrival_dt = _build_datetime_ymd_hms(date_str, time_str)
    if arrival_dt is None and time_str:
        hms = _parse_hms_token(time_str)
        if hms is not None:
            h, m, sec = hms
            arrival_dt = origin_dt.replace(hour=h, minute=m, second=int(sec), microsecond=0)
            micro = int((sec - int(sec)) * 1e6)
            arrival_dt = arrival_dt.replace(microsecond=micro)
            if arrival_dt < origin_dt:
                arrival_dt = arrival_dt + timedelta(days=1)
    if arrival_dt is None:
        return None
    return compute_relative_tt(origin_dt, arrival_dt, max_tt=max_tt)



def read_parameters(param_file='idp_hypoDD.inp'):
    lines = []
    try:
        with open(param_file, 'r', encoding='utf-8', errors='ignore') as f:
            for raw in f:
                line = raw.rstrip('\n')
                if line.strip().startswith('*') or not line.strip():
                    continue
                lines.append(line.strip())
    except FileNotFoundError:
        sys.exit(f"Parameter file '{param_file}' not found.")
    if len(lines) < 3:
        sys.exit(f"Need at least 3 non-comment lines in {param_file}.")
    return lines[0], lines[1], int(lines[2])


def china_time_to_utc(year, mon, day, h, mi, sec):
    """Convert China Time (UTC+8) to UTC"""
    try:
        # Create datetime object for China Time
        china_dt = datetime(year, mon, day, h, mi, int(sec))
        # Add microseconds
        microsec = int((sec - int(sec)) * 1e6)
        china_dt = china_dt.replace(microsecond=microsec)
        
        # Convert to UTC (subtract 8 hours)
        utc_dt = china_dt - timedelta(hours=8)
        
        # Extract components
        utc_sec = utc_dt.second + utc_dt.microsecond / 1e6
        return utc_dt.year, utc_dt.month, utc_dt.day, utc_dt.hour, utc_dt.minute, utc_sec
    except:
        # If conversion fails, return original values
        return year, mon, day, h, mi, sec


def parse_event_line(ln):
    """Parse JOPENS format event line and convert to UTC"""
    lst = list(ln)
    for p in (7, 10, 16, 19):
        if p < len(lst): lst[p] = ' '
    s = ''.join(lst)
    parts = s[:58].split()
    year, mon, day = map(int, parts[1:4])
    h, mi = int(parts[4]), int(parts[5])
    sec = float(parts[6])
    lat, lon, dep, mag = map(float, parts[7:11])
    mag = max(mag, 0.0)
    
    # Store China time for travel time calculation
    china_dt = datetime(year, mon, day, h, mi, int(sec))
    microsec = int((sec - int(sec)) * 1e6)
    china_dt = china_dt.replace(microsecond=microsec)
    
    # Convert to UTC for output
    year_utc, mon_utc, day_utc, h_utc, mi_utc, sec_utc = china_time_to_utc(year, mon, day, h, mi, sec)
    
    return year_utc, mon_utc, day_utc, h_utc, mi_utc, sec_utc, lat, lon, dep, mag, china_dt


def parse_dbo_event_line(ln):
    """Parse DBO format event line and convert to UTC"""
    parts = ln.split()
    if len(parts) < 10:
        return None
    
    # Parse date and time (China Time)
    date_time = parts[2] + ' ' + parts[3]  # "2024-12-31 17:17:07.64"
    date_part, time_part = date_time.split()
    year, mon, day = map(int, date_part.split('-'))
    time_parts = time_part.split(':')
    h = int(time_parts[0])
    mi = int(time_parts[1])
    sec = float(time_parts[2])
    
    # Parse location - lat and lon are after time
    lat = float(parts[4])
    lon = float(parts[5])
    
    # Find depth and magnitude
    dep = 0.0
    mag = 0.0
    
    for i in range(6, len(parts)):
        try:
            val = float(parts[i])
            if dep == 0.0 and 0 <= val <= 700:
                dep = val
        except ValueError:
            if parts[i] in ['ML', 'Ms', 'mb', 'mB', 'Mw']:
                if i+1 < len(parts):
                    try:
                        mag = float(parts[i+1])
                    except ValueError:
                        pass
    
    mag = max(mag, 0.0)
    
    # Store China time datetime for travel time calculation
    china_dt = datetime(year, mon, day, h, mi, int(sec))
    microsec = int((sec - int(sec)) * 1e6)
    china_dt = china_dt.replace(microsecond=microsec)
    
    # Convert to UTC for output
    year_utc, mon_utc, day_utc, h_utc, mi_utc, sec_utc = china_time_to_utc(year, mon, day, h, mi, sec)
    
    return year_utc, mon_utc, day_utc, h_utc, mi_utc, sec_utc, lat, lon, dep, mag, china_dt


def parse_obs_line(ln, origin_dt):
    """Parse JOPENS format observation line"""
    lst = list(ln)
    for p in (34, 37):
        if p < len(lst): lst[p] = ' '
    s = ''.join(lst)
    fields = s[17:44].split()
    if len(fields) < 6:
        return None, None, None, None, None
    rawpha = fields[0]
    # only Pg and Sg
    if rawpha == 'Pg':
        pchar = 'P'
    elif rawpha == 'Sg':
        pchar = 'S'
    else:
        return None, None, None, None, None
    try:
        h2 = int(float(fields[3])); m2 = int(float(fields[4])); sec2 = float(fields[5])
    except ValueError:
        return None, None, None, None, None
    
    # Create arrival datetime (China Time)
    arrival_dt = origin_dt.replace(hour=h2, minute=m2, second=int(sec2), microsecond=0)
    microsec = int((sec2 - int(sec2)) * 1e6)
    arrival_dt = arrival_dt.replace(microsecond=microsec)
    
    # Handle day crossing
    if arrival_dt < origin_dt:
        arrival_dt = arrival_dt + timedelta(days=1)
    # Calculate travel time in seconds (robust cross-midnight fix)
    tt = compute_relative_tt(origin_dt, arrival_dt, max_tt=MAX_TRAVEL_TIME_FALLBACK)

    if tt is None:
        return None, None, None, None, None
    
    if s[:3] != '   ':
        sc = s[0:2].strip()
        sx = s[2:7].strip()
    else:
        return None, None, None, None, None
    return sc, sx, tt, rawpha, pchar


def parse_dpb_obs_line(ln, origin_dt):
    """Parse DPB format observation line with robust cross-midnight handling.

    This 'Pg/Sg only' variant:
      - Accepts only Pg->P and Sg->S
      - If a station has Pn/Sn/P/S, return (sc,sx,None,rawpha,None) so caller can apply skip logic
      - Handles DPB lines that may omit YYYY-MM-DD by falling back to time-only parsing
    """
    parts = ln.split()
    if len(parts) < 4:
        return None, None, None, None, None

    network = parts[1]
    station = parts[2]

    # Find phase (Pg/Sg only); if other phases appear, pass them upward for skip logic
    phase = None
    rawpha = None
    for i in range(3, min(10, len(parts))):
        tok = parts[i]
        if tok in ('Pg', 'Sg'):
            phase = tok
            rawpha = tok
            break
        if tok in ('Pn', 'Sn', 'P', 'S'):
            sc = network[:2].strip()
            sx = station[:5].strip()
            return sc, sx, None, tok, None

    if phase is None:
        return None, None, None, None, None

    # Try to find YYYY-MM-DD + time; otherwise fall back to time-only
    date_str = None
    time_str = None
    for i, tok in enumerate(parts):
        if len(tok) == 10 and tok[4] == '-' and tok[7] == '-' and tok[:4].isdigit():
            date_str = tok
            if i + 1 < len(parts) and parts[i + 1].count(':') == 2:
                time_str = parts[i + 1]
            break
    if time_str is None:
        for tok in parts:
            if tok.count(':') == 2:
                time_str = tok
                break

    tt = compute_tt_from_tokens(origin_dt, date_str=date_str, time_str=time_str, max_tt=MAX_TRAVEL_TIME_FALLBACK)
    if tt is None:
        return None, None, None, None, None

    sc = network[:2].strip()
    sx = station[:5].strip()
    pchar = 'P' if phase == 'Pg' else 'S'
    return sc, sx, tt, rawpha, pchar

def detect_format(filename):
    """Detect file format by checking first few lines"""
    try:
        with open(filename, 'r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                line = line.strip()
                if line.startswith('DBO'):
                    return 'DBO'
                elif len(line) > 10 and line[7] == '/' and line[10] == '/':
                    return 'JOPENS'
    except:
        return None
    return None


def process_jopens_format(evf, fout, nev_start, istart):
    """Process JOPENS format file"""
    nev = nev_start
    prev_j2 = False
    current_origin_dt = None
    printed_P = set()
    printed_S = set()
    skip_P = set()
    skip_S = set()
    prev_sc = ''
    prev_sx = ''
    
    with open(evf, 'r', encoding='utf-8', errors='ignore') as fev:
        for raw in fev:
            ln = raw.rstrip('\n')
            slash = len(ln) >= 8 and ln[7] == '/'
            region_nb = any(ch != ' ' for ch in ln[25:42])
            if slash:
                prev_j2 = region_nb
            if slash and prev_j2:
                nev += 1
                y, m, d, h, mi, s, lat, lon, dep, mag, origin_dt = parse_event_line(ln)
                gid = nev + istart - 1
                fout.write(
                    f"#{y:5d} {m:2d} {d:2d} {h:2d} {mi:2d} {s:5.2f} "
                    f"{lat:8.4f} {lon:9.4f} {dep:7.2f}  {mag:5.2f}  {gid:10d}\n"
                )
                current_origin_dt = origin_dt
                printed_P.clear()
                printed_S.clear()
                skip_P.clear()
                skip_S.clear()
                prev_sc = ''
                prev_sx = ''
            elif not slash and prev_j2 and region_nb:
                # mark stations with Pn/Sn for skipping
                rawpha_peek = ''.join(list(ln)[:44])[17:44].split()[0] if len(ln) >= 44 else ''
                if rawpha_peek == 'Pn':
                    skip_P.add(prev_sc + prev_sx)
                elif rawpha_peek == 'Sn':
                    skip_S.add(prev_sc + prev_sx)
                sc, sx, tt, rawpha, pchar = parse_obs_line(ln, current_origin_dt)
                if sc is None:
                    continue
                prev_sc, prev_sx = sc, sx
                key = sc + sx
                # skip any P/S if Pn/Sn occurred at that station
                if pchar == 'P' and key in skip_P:
                    continue
                if pchar == 'S' and key in skip_S:
                    continue
                # threshold filtering
                if (pchar == 'P' and tt > 20.0) or (pchar == 'S' and tt > 40.0):
                    continue
                # earliest-phase filtering
                if pchar == 'P':
                    if key in printed_P:
                        continue
                    printed_P.add(key)
                else:
                    if key in printed_S:
                        continue
                    printed_S.add(key)
                # Output format: station network traveltime phase
                fout.write(f"{sx} {sc} {tt:8.2f} {pchar}\n")
    
    return nev


def process_dbo_format(evf, fout, nev_start, istart):
    """Process DBO/DPB format file"""
    nev = nev_start
    current_origin_dt = None
    current_event_active = False
    printed_P = set()
    printed_S = set()
    skip_P = set()
    skip_S = set()
    
    with open(evf, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            line = line.strip()
            
            if line.startswith('DBO'):
                # New event
                event_data = parse_dbo_event_line(line)
                if event_data:
                    nev += 1
                    y, m, d, h, mi, s, lat, lon, dep, mag, origin_dt = event_data
                    gid = nev + istart - 1
                    fout.write(
                        f"#{y:5d} {m:2d} {d:2d} {h:2d} {mi:2d} {s:5.2f} "
                        f"{lat:8.4f} {lon:9.4f} {dep:7.2f}  {mag:5.2f}  {gid:10d}\n"
                    )
                    current_origin_dt = origin_dt
                    current_event_active = True
                    printed_P.clear()
                    printed_S.clear()
                    skip_P.clear()
                    skip_S.clear()
            
            elif line.startswith('DPB') and current_event_active and current_origin_dt is not None:
                # Parse observation line
                sc, sx, tt, rawpha, pchar = parse_dpb_obs_line(line, current_origin_dt)
                
                if sc is None:
                    continue
                
                # Mark stations with Pn/Sn for skipping
                if rawpha == 'Pn':
                    skip_P.add(sc + sx)
                    continue
                elif rawpha == 'Sn':
                    skip_S.add(sc + sx)
                    continue
                
                # Only process if we got valid Pg/Sg
                if tt is None or pchar is None:
                    continue
                
                key = sc + sx
                
                # Skip any P/S if Pn/Sn occurred at that station
                if pchar == 'P' and key in skip_P:
                    continue
                if pchar == 'S' and key in skip_S:
                    continue
                
                # Threshold filtering
                if (pchar == 'P' and tt > 20.0) or (pchar == 'S' and tt > 40.0):
                    continue
                
                # Earliest-phase filtering
                if pchar == 'P':
                    if key in printed_P:
                        continue
                    printed_P.add(key)
                else:
                    if key in printed_S:
                        continue
                    printed_S.add(key)
                
                # Output format: station network traveltime phase
                fout.write(f"{sx} {sc} {tt:8.2f} {pchar}\n")
    
    return nev


def main():
    evcat, phaseps, istart = read_parameters()
    
    # Check if evcat is a list file or a single file
    if os.path.exists(evcat):
        try:
            with open(evcat, 'r', encoding='utf-8', errors='ignore') as f:
                first_line = f.readline().strip()
                f.seek(0)
                
                # If first line starts with DBO, it's a data file
                if first_line.startswith('DBO'):
                    evfiles = [evcat]
                else:
                    # It's a catalog list
                    evfiles = [l.strip() for l in f if l.strip()]
        except:
            sys.exit(f"Error reading event catalog '{evcat}'.")
    else:
        sys.exit(f"Event catalog '{evcat}' not found.")
    
    nev = 0
    with open(phaseps, 'w', encoding='utf-8', errors='ignore') as fout:
        for evf in evfiles:
            if not os.path.exists(evf):
                print(f"Warning: event file '{evf}' not found, skipping.")
                continue
            
            # Detect format
            file_format = detect_format(evf)
            if not file_format:
                print(f"Warning: unable to detect format for '{evf}', skipping.")
                continue
            
            print(f"Processing {evf} in {file_format} format...")
            
            if file_format == 'JOPENS':
                nev = process_jopens_format(evf, fout, nev, istart)
            elif file_format == 'DBO':
                nev = process_dbo_format(evf, fout, nev, istart)
        
        fout.flush()
    
    print(f"Finished: events={nev}, output={phaseps}")


if __name__ == '__main__':
    main()