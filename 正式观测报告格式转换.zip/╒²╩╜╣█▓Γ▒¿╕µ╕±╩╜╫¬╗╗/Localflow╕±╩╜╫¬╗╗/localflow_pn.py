#!/usr/bin/env python3
"""
Reads parameter file 'idp_hypoDD.inp', reads event catalog,
converts both JOPENS-format and DBO/DPB format files to localflow phase format,
preserving core I/O logic:
- Map Pg, Pn, P to P; Sg, Sn, S to S
- Filter earliest P-phase and earliest S-phase per station
Usage:
    python localflow_pn.py
    
Author: Suxiang Zhang
Work unit: Shanghai Earthquake Agency
Modified to support DBO/DPB format
"""
import os
import sys


def read_parameters(param_file='idp_hypoDD.inp'):
    lines = []
    try:
        with open(param_file, 'r', encoding='utf-8', errors='ignore') as f:
            for raw in f:
                line = raw.rstrip('\n')
                if line.strip().startswith('*') or not line.strip():
                    continue
                lines.append(line.strip())
    except FileNotFoundError:
        sys.exit(f"Parameter file '{param_file}' not found.")
    if len(lines) < 3:
        sys.exit(f"Need at least 3 non-comment lines in {param_file}.")
    return lines[0], lines[1], int(lines[2])


def parse_event_line(ln):
    """Parse JOPENS format event line"""
    lst = list(ln)
    for p in (7, 10, 16, 19):
        if p < len(lst): lst[p] = ' '
    s = ''.join(lst)
    parts = s[:58].split()
    year, mon, day = map(int, parts[1:4])
    h, mi = int(parts[4]), int(parts[5])
    sec = float(parts[6])
    lat, lon, dep, mag = map(float, parts[7:11])
    mag = max(mag, 0.0)
    t1 = h*3600 + mi*60 + sec
    return year, mon, day, h, mi, sec, lat, lon, dep, mag, t1


def parse_dbo_event_line(ln):
    """Parse DBO format event line"""
    parts = ln.split()
    if len(parts) < 10:
        return None
    
    # Parse date and time
    date_time = parts[2] + ' ' + parts[3]  # "2024-12-31 17:17:07.64"
    date_part, time_part = date_time.split()
    year, mon, day = map(int, date_part.split('-'))
    time_parts = time_part.split(':')
    h = int(time_parts[0])
    mi = int(time_parts[1])
    sec = float(time_parts[2])
    
    # Parse location - lat and lon are after time
    lat = float(parts[4])
    lon = float(parts[5])
    
    # Find depth and magnitude
    dep = 0.0
    mag = 0.0
    
    for i in range(6, len(parts)):
        try:
            val = float(parts[i])
            if dep == 0.0 and 0 <= val <= 700:
                dep = val
        except ValueError:
            if parts[i] in ['ML', 'Ms', 'mb', 'mB', 'Mw']:
                if i+1 < len(parts):
                    try:
                        mag = float(parts[i+1])
                    except ValueError:
                        pass
    
    mag = max(mag, 0.0)
    t1 = h * 3600 + mi * 60 + sec
    return year, mon, day, h, mi, sec, lat, lon, dep, mag, t1


def parse_obs_line(ln, t1):
    """Parse JOPENS format observation line"""
    lst = list(ln)
    for p in (34, 37):
        if p < len(lst): lst[p] = ' '
    s = ''.join(lst)
    fields = s[17:44].split()
    if len(fields) < 6:
        return None, None, None, None
    rawpha = fields[0]
    if rawpha in ('Pg', 'Pn', 'P'):
        pchar = 'P'
    elif rawpha in ('Sg', 'Sn', 'S'):
        pchar = 'S'
    else:
        return None, None, None, None
    try:
        h2 = int(float(fields[3]))
        m2 = int(float(fields[4]))
        sec2 = float(fields[5])
    except:
        return None, None, None, None
    t2 = h2*3600 + m2*60 + sec2
    tt = t2 - t1
    if tt <= 0:
        return None, None, None, None
    if s[:3] != '   ':
        sc = s[0:2].strip()
        sx = s[2:7].strip()
    else:
        return None, None, None, None
    return sc, sx, tt, pchar


def parse_dpb_obs_line(ln, t1):
    """Parse DPB format observation line - accept all P and S types"""
    parts = ln.split()
    if len(parts) < 10:
        return None, None, None, None
    
    # Extract station info
    network = parts[1]
    station = parts[2]
    
    # Find the phase - accept Pg, Pn, P, Sg, Sn, S
    phase = None
    for i in range(3, min(10, len(parts))):
        if parts[i] in ('Pg', 'Pn', 'P'):
            phase = 'P'
            break
        elif parts[i] in ('Sg', 'Sn', 'S'):
            phase = 'S'
            break
    
    if not phase:
        return None, None, None, None
    
    # Find the date-time pattern
    arrival_time = None
    for i in range(len(parts)):
        if '-' in parts[i] and len(parts[i]) == 10:
            try:
                year_test = int(parts[i][:4])
                if 1900 <= year_test <= 2100:
                    if i+1 < len(parts) and ':' in parts[i+1]:
                        time_str = parts[i+1]
                        time_parts = time_str.split(':')
                        if len(time_parts) == 3:
                            h2 = int(time_parts[0])
                            m2 = int(time_parts[1])
                            sec2 = float(time_parts[2])
                            arrival_time = h2 * 3600 + m2 * 60 + sec2
                            break
            except (ValueError, IndexError):
                continue
    
    if arrival_time is None:
        return None, None, None, None
    
    # Calculate travel time
    tt = arrival_time - t1
    if tt <= 0:
        return None, None, None, None
    
    # Format station code
    sc = network[:2].strip()
    sx = station[:5].strip()
    
    return sc, sx, tt, phase


def detect_format(filename):
    """Detect file format by checking first few lines"""
    try:
        with open(filename, 'r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                line = line.strip()
                if line.startswith('DBO'):
                    return 'DBO'
                elif len(line) > 10 and line[7] == '/' and line[10] == '/':
                    return 'JOPENS'
    except:
        return None
    return None


def process_jopens_format(evf, fout, nev_start, istart):
    """Process JOPENS format file"""
    nev = nev_start
    prev_j2 = False
    prev_t1 = 0.0
    printed_P = set()
    printed_S = set()
    prev_sc = ''
    prev_sx = ''
    
    with open(evf, 'r', encoding='utf-8', errors='ignore') as fev:
        for raw in fev:
            ln = raw.rstrip('\n')
            slash = len(ln) >= 8 and ln[7] == '/'
            region_nb = any(ch != ' ' for ch in ln[25:42])
            if slash:
                prev_j2 = region_nb
            if slash and prev_j2:
                nev += 1
                y, m, d, h, mi, s, lat, lon, dep, mag, t1 = parse_event_line(ln)
                gid = nev + istart - 1
                fout.write(
                    f"#{y:5d} {m:2d} {d:2d} {h:2d} {mi:2d} {s:5.2f} "
                    f"{lat:8.4f} {lon:9.4f} {dep:7.2f}  {mag:5.2f}  {gid:10d}\n"
                )
                prev_t1 = t1
                printed_P.clear()
                printed_S.clear()
                prev_sc = ''
                prev_sx = ''
            elif not slash and prev_j2 and region_nb:
                sc, sx, tt, pchar = parse_obs_line(ln, prev_t1)
                if sc is None:
                    continue
                prev_sc, prev_sx = sc, sx
                key = sc + sx
                if pchar == 'P':
                    if key in printed_P:
                        continue
                    printed_P.add(key)
                else:
                    if key in printed_S:
                        continue
                    printed_S.add(key)
                fout.write(f"{sc}{sx} {sc} {tt:8.2f} {pchar}\n")
    
    return nev


def process_dbo_format(evf, fout, nev_start, istart):
    """Process DBO/DPB format file"""
    nev = nev_start
    current_t1 = 0.0
    current_event_active = False
    printed_P = set()
    printed_S = set()
    
    with open(evf, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            line = line.strip()
            
            if line.startswith('DBO'):
                # New event
                event_data = parse_dbo_event_line(line)
                if event_data:
                    nev += 1
                    y, m, d, h, mi, s, lat, lon, dep, mag, t1 = event_data
                    gid = nev + istart - 1
                    fout.write(
                        f"#{y:5d} {m:2d} {d:2d} {h:2d} {mi:2d} {s:5.2f} "
                        f"{lat:8.4f} {lon:9.4f} {dep:7.2f}  {mag:5.2f}  {gid:10d}\n"
                    )
                    current_t1 = t1
                    current_event_active = True
                    printed_P.clear()
                    printed_S.clear()
            
            elif line.startswith('DPB') and current_event_active and current_t1 > 0:
                # Parse observation line
                sc, sx, tt, pchar = parse_dpb_obs_line(line, current_t1)
                
                if sc is None or tt is None or pchar is None:
                    continue
                
                key = sc + sx
                
                # Earliest-phase filtering
                if pchar == 'P':
                    if key in printed_P:
                        continue
                    printed_P.add(key)
                else:
                    if key in printed_S:
                        continue
                    printed_S.add(key)
                
                fout.write(f"{sc}{sx} {sc} {tt:8.2f} {pchar}\n")
    
    return nev


def main():
    evcat, phaseps, istart = read_parameters()
    
    # Check if evcat is a list file or a single file
    if os.path.exists(evcat):
        try:
            with open(evcat, 'r', encoding='utf-8', errors='ignore') as f:
                first_line = f.readline().strip()
                f.seek(0)
                
                # If first line starts with DBO, it's a data file
                if first_line.startswith('DBO'):
                    evfiles = [evcat]
                else:
                    # It's a catalog list
                    evfiles = [l.strip() for l in f if l.strip()]
        except:
            sys.exit(f"Error reading event catalog '{evcat}'.")
    else:
        sys.exit(f"Event catalog '{evcat}' not found.")
    
    nev = 0
    with open(phaseps, 'w', encoding='utf-8', errors='ignore') as fout:
        for evf in evfiles:
            if not os.path.exists(evf):
                print(f"Warning: event file '{evf}' not found, skipping.")
                continue
            
            # Detect format
            file_format = detect_format(evf)
            if not file_format:
                print(f"Warning: unable to detect format for '{evf}', skipping.")
                continue
            
            print(f"Processing {evf} in {file_format} format...")
            
            if file_format == 'JOPENS':
                nev = process_jopens_format(evf, fout, nev, istart)
            elif file_format == 'DBO':
                nev = process_dbo_format(evf, fout, nev, istart)
        
        fout.flush()
    
    print(f"Finished: events={nev}, output={phaseps}")


if __name__ == '__main__':
    main()